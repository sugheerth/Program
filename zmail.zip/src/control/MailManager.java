package control;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.channels.FileChannel;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Email;


public class MailManager {

	@SuppressWarnings("resource")
	public static void sendMail(String from, String to, String body) throws IOException {
		try {
			
			ObjectOutputStream obj = new ObjectOutputStream( new FileOutputStream(from+"sent.bin",true)){
				protected void writeStreamHeader() throws IOException
				{
					reset();
				}
			};
			Email email = new Email();
			email.setBody(body);
			email.setId(to);
			obj.writeObject(email);
			obj.flush();
			obj.close();
			
			obj = new ObjectOutputStream(new FileOutputStream(to+"inbox.bin",true)){
				protected void writeStreamHeader() throws IOException
				{
					reset();
				}
			};
			email = new Email();
			email.setBody(body);
			email.setId(from);
			obj.writeObject(email);
			obj.flush();
			obj.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
	}
	
		public static void displayMails(String uname, String opt) throws IOException, ClassNotFoundException {
		
			FileInputStream file = new FileInputStream(uname+opt+".bin");
			ObjectInputStream obj = new ObjectInputStream(file){
					protected void readStreamHeader() throws IOException
					{
						
					}
				};
	
			if(opt.equals("sent"))
			{
				System.out.println("\n------------------------\n	SENT :\n------------------------");
				
			}
			else
			{
				System.out.println("\n------------------------\n	INBOX :\n------------------------");
				
			}
			boolean flag = false;
			
			Email email = new Email();
			try {
				
				while((email = (Email)obj.readObject()) != null)
				{
					
					{
						flag =true;
						System.out.println("\nMailId : "+email.getId()+"\nDate : "+email.getDate()+"\nTime : "+email.getTime()+"\nBody : "+email.getBody());
					}
					
					
				}
			} catch (Exception e) {
				
			}
			
			if(!flag)
			{
				System.out.println("\nNo mails found!!!! ");
			}
			System.out.println("\n------------------------");
			obj.close();
			file.close();
		}
		
		public static void searchMails(String uname, String name, String opt) throws ClassNotFoundException, IOException {
			FileInputStream file = new FileInputStream(uname+opt+".bin");
			ObjectInputStream obj = new ObjectInputStream(file){
					protected void readStreamHeader() throws IOException
					{
						
					}
				};
			if(opt.equals("sent"))
			{
				System.out.println("\n-----------------------------------\n	SENT : MAILS FROM "+ name +" \n-----------------------------------");
				
			}
			else
			{
				System.out.println("\n-----------------------------------\n	INBOX : MAILS FROM "+ name +" \n-----------------------------------");
				
			}
			boolean flag = false;
			Email email = new Email();
			try {
				
				while((email = (Email)obj.readObject()) != null)
				{
					
					if(email.getId().equals(name))
					{
						flag =true;
						System.out.println("\nMailId : "+email.getId()+"\nDate : "+email.getDate()+"\nTime : "+email.getTime()+"\nBody : "+email.getBody());
					}
					
				}
			} catch (Exception e) {
				
			}
			if(!flag)
			{
				System.out.println("\nNo mails found!!!! ");
			}
			System.out.println("\n-----------------------------------");
			obj.close();
			file.close();
			
		}
		
		public static void printUnreadMails(String uname) throws IOException, SQLException
		{
			 FileInputStream loggedFile = new FileInputStream(uname+"inbox.bin");
		 	 FileChannel fc = loggedFile.getChannel();
			 ObjectInputStream obj = new ObjectInputStream(loggedFile){
		  	 	protected void readStreamHeader() throws IOException
	 		 	{
		
			 	}
			 };
			 long pos = DAO.getFileSize(uname);
			 if(fc.size() != pos)
			 {
			 	fc.position(pos);
				Email mail = new Email();
				ArrayList<Email> emailArray = new ArrayList<Email>();
				try
				{
					while( (mail = (Email)obj.readObject()) != null)
					{
						emailArray.add(mail);
					}
				}
				catch(Exception e)
				{
				}
				System.out.println("\n--------------------------------------------------------------------");
				System.out.println("\nYou have " + emailArray.size() + " new messages : ");
				for(Email email : emailArray)
				{
					System.out.println("\nFrom : "+email.getId()+"\nDate : "+email.getDate()+"\nTime : "+email.getTime()+"\nBody : "+email.getBody());
				}
				System.out.println("\n--------------------------------------------------------------------");
			}
			obj.close();
			fc.close();
			loggedFile.close();
		}
}
