package control;


import java.io.*;
import java.nio.channels.*;
import model.Email;

public class Logged implements Runnable{

	String fileName = new String();
	private boolean alive;
	
	public void setAlive(boolean alive)
	{
		this.alive = alive;
	}
	public Logged(String fileName) {
		super();
		this.fileName = fileName;
		this.alive = true;
	}


	public void run()
	{
		try {
			
			
			Email email = new Email();
			FileInputStream file = new FileInputStream(fileName);
			FileChannel fc = file.getChannel();
			
			long length = fc.size();
		
			while(alive)
			{
			
				
				fc = file.getChannel();
				if(length!=fc.size())
					{
						
						fc.position(length);
							ObjectInputStream obj = new ObjectInputStream(file){
								protected void readStreamHeader() throws IOException
								{
					
								}
							};
							
							try
							{
								
								email = (Email)obj.readObject();
								length = fc.position();
								System.out.println("\n--------------------------------------------------------------------");
								System.out.println("\nNew Mail Received From"+" : "+email.getId()+"\nDate : "+email.getDate()+"\nTime : "+email.getTime()+"\nBody : "+email.getBody());	
								System.out.println("\n--------------------------------------------------------------------");
							}
							catch(Exception e)
							{
							}
						
					}
				}
		
		file.close();	
		} catch (IOException e) {
							
		}
		
	}
}	