package control;



import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class DAO {

	public static boolean ifExists(String uname, String pass) throws SQLException
	{
		 boolean check;
		 Connection con = DriverManager.getConnection("jdbc:sqlite:accounts.db");
		 Statement st = con.createStatement();
		 ResultSet rs = st.executeQuery("SELECT * FROM accounts WHERE mailid = '" + uname + "' AND password = '" + pass + "'");
		 if(rs.next())
			 	check = true;
		 else
			 	check = false;
		 st.close();
		 con.close();
		 return check;
	}
	
	public static long getFileSize(String uname) throws SQLException
	{
		Connection con = DriverManager.getConnection("jdbc:sqlite:accounts.db");
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("SELECT * FROM accounts WHERE mailid = '" + uname + "'");
		rs.next();
		int size = rs.getInt(3);
		st.close();
		con.close();
		return size;
	}

	public static boolean ifExists(String uname) throws SQLException {
		Connection con = DriverManager.getConnection("jdbc:sqlite:accounts.db");
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("SELECT * FROM accounts WHERE mailid = '" + uname + "'");
		boolean check;
		if(rs.next())
			 	check = true;
		else
			 	check = false;
		st.close();
		con.close();
		return check;
	}

	public static void createAccount(String uname, String password) throws SQLException, IOException {
		
		 Connection con = DriverManager.getConnection("jdbc:sqlite:accounts.db");
		 Statement st = con.createStatement();
		 st.executeUpdate("INSERT INTO accounts VALUES('" + uname + "','" + password + "',0)");
		 FileOutputStream file = new FileOutputStream(uname +"sent.bin");
		 file.close();
		 file = new FileOutputStream(uname +"inbox.bin");
		 file.close();
		 st.close();
		 con.close();
	}

	public static void setFileSize(String uname) throws SQLException, IOException
	{
		FileInputStream loggedFile = new FileInputStream(uname+"inbox.bin");
		FileChannel fc = loggedFile.getChannel();
		Connection con = DriverManager.getConnection("jdbc:sqlite:accounts.db");
		Statement st = con.createStatement();
		st.executeUpdate("UPDATE accounts SET size = " + fc.size() + " WHERE mailid = '" + uname + "'");
		fc.close();
		loggedFile.close();
		st.close();
		con.close();
	}

	public static void deleteAccount(String uname) throws SQLException
	{
		Connection con = DriverManager.getConnection("jdbc:sqlite:accounts.db");
		Statement st = con.createStatement();
		st.executeUpdate("DELETE FROM accounts WHERE mailid = '" + uname + "'");
		System.out.println("\n------------------------");
		System.out.println("\nAccount Deleted!");
		System.out.println("\n------------------------");
		File delFile = new File(uname+"sent.bin");
		delFile.delete();
		delFile = new File(uname+"inbox.bin");
		delFile.delete();
		st.close();
		con.close();
	}
}
