package control;


import java.util.regex.Pattern;


public class Validate {

	public static  String validateId(String id)
	{
		if(!(id.endsWith("@zmail.com")))
		{
			id = id.concat("@zmail.com");
		}
		return id;
		
	}
	
	public static boolean validatePassword(String password)
	{
		return Pattern.matches("^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[!@#$%^&*]).{8,}$",password );
		
	}

	public static boolean validateUname(String uName)
	{
		return Pattern.matches("[a-z0-9]+",uName );
		
	}
}
