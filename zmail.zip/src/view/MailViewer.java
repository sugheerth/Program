package view;


import java.util.*;
import java.io.*;
import java.sql.*;
import control.*;

public class MailViewer {

	

	public static void main(String args[]) throws IOException, SQLException, ClassNotFoundException, InterruptedException
	{
		
		Scanner get = new Scanner(System.in);
		char choice = 'y';
		String uname = new String();
		String password = new String();
		Connection con = DriverManager.getConnection("jdbc:sqlite:accounts.db");
		Statement st = con.createStatement();
		st.execute("CREATE TABLE IF NOT EXISTS accounts('mailid' text(25),'password' text(20), 'size' int(15))");
		st.close();
		con.close();
		do
		{	
			System.out.println("\n--------------------------------------------------------------------\n	WELCOME TO ZMAIL :\n--------------------------------------------------------------------");
			System.out.println("\n1. Login\n2. Sign Up");
			int ch = get.nextInt();
			switch(ch)
			{
				case 1 : System.out.println("\nEnter the mailid : ");
					 	 uname = get.next();
					 	 uname = Validate.validateId(uname);
					 	 System.out.println("Enter the password : ");
					 	 password = get.next();
					 	 if(!DAO.ifExists(uname, password))
					 	 {
					 		 System.out.println("Account doesn't exist");
					 	 }
					 	 else
					 	 {
							 
							 MailManager.printUnreadMails(uname);
								
							 Logged log = new Logged(uname+"inbox.bin");
							 Thread check = new Thread(log);
							 check.start();
							 while(choice == 'y' || choice == 'Y')
							 {
								 System.out.print("\n1. Send mail\n2. Sent Mails\n3. Inbox\n4. Search mails in inbox\n5. Search mail in sent mail \n6. Delete Account \n7. Logout ");
								 ch = get.nextInt();
								 switch(ch)
								 {
								 
								 	case 1 : System.out.print("\nTo : ");
								 		 	 String name = get.next();
								 		 	 if(!name.endsWith("@zmail.com"))
								 		 	 {
								 		 		 System.out.println("\nNot a vaild EmailId! Should end with @zmail.com");
								 		 	 }
								 		 	 else 
								 		 	 {
								 		 		 if(!DAO.ifExists(name))
								 		 		 {
								 		 			 System.out.println("Account doesnt exist");
								 		 		 }
								 		 		 else
								 		 		 {
								 		 			 System.out.print("\nEnter the body of the message : ");
								 		 			 get.nextLine();
								 		 			 String body = get.nextLine();
								 		 			 MailManager.sendMail(uname,name,body);
								 		 		 }
								 		 	 }
								 		 	 break;
								 	case 2 : MailManager.displayMails(uname,new String("sent"));
								 			 break;
								 	case 3 : MailManager.displayMails(uname, new String("inbox"));
								 			 break;
								 	case 4 : System.out.print("\nEnter name to search : ");
									      	 name = get.next();
									      	 name = Validate.validateId(name);
									      	 MailManager.searchMails(uname,name,"inbox");
									      	 break;
								 	case 5 : System.out.print("\nEnter name to search : ");
									 	 	 name = get.next();
									 	 	 name = Validate.validateId(name);
									 	 	 MailManager.searchMails(uname,name,"sent");
									 	 	 break;
								 	case 6 : DAO.deleteAccount(uname);
										 	 choice = 'n';
										 	 break;
								 	case 7 : log.setAlive(false);
										 	 System.out.println("\nLogging out......");
										 	 Thread.sleep(2000);
										 	 DAO.setFileSize(uname);
										 	 choice = 'n';
										 	 break;
							 	  
								 	}
							 
							}
							
						 
						 }
					 break;
			case 2 : boolean flag = false;
					 while(!flag)
					 {
						System.out.print("\nEnter the username : ");
					 	uname = get.next();
						if(!Validate.validateUname(uname))
					 	{
							System.out.println("\nInvalid username!");
						}
						else
						{
			  		 		uname = Validate.validateId(uname);
					 		if(DAO.ifExists(uname))
					 		{
						 		System.out.println("Account already exists");
							}
							else
							{
								flag =true;
							}
							
						}
						 
					 }
					 System.out.print("Enter the password\n(Should contain at least \n1 uppercase letter, \n1 lowercase letter, \n1 digit  \n1 of the special characters [!@#$%^&*])\nMinimum 8 characters : ");
					 password = get.next();
					 while(!Validate.validatePassword(password))
					 {
					 	System.out.println("Invalid password, re- enter");
						password = get.next();
					 }
					 
					 DAO.createAccount(uname,password);
					 break;
			default : System.out.println("\nInvaild Choice");
					  break;
					  
			}
			System.out.println("Continue?<y/n>");
			choice = (char)System.in.read();
		}while(choice == 'y' || choice == 'Y'); 
		get.close();
		
	}
	
	
		
}